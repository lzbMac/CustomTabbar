//
//  AppDelegate.h
//  CustomTabbarContrller
//
//  Created by 李正兵 on 16/4/26.
//  Copyright © 2016年 李正兵. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

