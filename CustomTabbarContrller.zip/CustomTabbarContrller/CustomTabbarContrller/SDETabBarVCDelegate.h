//
//  SDETabBarVCDelegate.h
//  CustomTabbarContrller
//
//  Created by 李正兵 on 16/4/26.
//  Copyright © 2016年 李正兵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SDETabBarVCDelegate : NSObject<UITabBarControllerDelegate>

@property(nonatomic, assign)BOOL interactive;

@property(nonatomic)UIPercentDrivenInteractiveTransition *interactionController;

@end
