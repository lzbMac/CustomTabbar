//
//  SDETabBarVCDelegate.m
//  CustomTabbarContrller
//
//  Created by 李正兵 on 16/4/26.
//  Copyright © 2016年 李正兵. All rights reserved.
//

#import "SDETabBarVCDelegate.h"

@implementation SDETabBarVCDelegate

- (id)init {
    self = [super init];
    if (self) {
        _interactive = NO;
        _interactionController = [UIPercentDrivenInteractiveTransition new];
    }
    return self;
}

- (id<UIViewControllerAnimatedTransitioning>)tabbarController:(UITabBarController *)tabbarController animationControllerForTransitionFromVC: (UIViewController *)fromViewController  toVC:(UIViewController *)toViewController{
    NSInteger fromIndex = [tabbarController.viewControllers indexOfObject:fromViewController];
    NSInteger toIndex = [tabbarController.viewControllers indexOfObject:toViewController];
    
}

@end
